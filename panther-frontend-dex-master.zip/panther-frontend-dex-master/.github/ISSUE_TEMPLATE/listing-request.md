---
name: Listing request
about: Request a listing
title: '[Listing] Request listing for {ADD TOKEN NAME HERE}'
labels: listing
assignees: Chef-Chungus
---

**Token information**
